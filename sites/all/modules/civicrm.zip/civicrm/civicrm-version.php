<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.1.0',
                'cms'      => 'Drupal6',
                'revision' => '38830' );
}

